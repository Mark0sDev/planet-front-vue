export enum ETabsID {
  GAME = 'game',
  BALANCE = 'balance',
  REFS = 'refs',
  WITHDRAWAL = 'withdrawal',
}
