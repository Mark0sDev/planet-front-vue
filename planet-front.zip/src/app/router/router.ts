export enum AppRoutes {
  HOME = '/',
  LEADERS = '/leaders',
  FRIENDS = '/friends',
  TASKS = '/tasks',
  BALANCE = '/balance',
  PLANETS = '/planets',
  FAQ = '/faq',
  ROULETTE = '/roulette',
}
